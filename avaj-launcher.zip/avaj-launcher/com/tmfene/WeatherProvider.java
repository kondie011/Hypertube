package com.tmfene;

import java.util.Random;

public class WeatherProvider {
    private static WeatherProvider weatherProvider = new WeatherProvider();
    private String[] weather = {"RAIN", "FOG", "SUN", "SNOW"};

    private WeatherProvider(){
    }

    public static WeatherProvider getProvider(){
        return WeatherProvider.weatherProvider;
    }

    public String getCurrentWeather(Coordinates coordinates){
        //Random r = new Random();

        //return weather[r.nextInt(4)];
       // return "SNOW";

       Random r = new Random();

     int lat = coordinates.getLatitude() * (r.nextInt(10));
      int lon = coordinates.getLongitude() * (r.nextInt(10));
      int height = coordinates.getHeight() * (r.nextInt(10));
      return this.weather[(lat + lon + height) % 4];
    }
}
