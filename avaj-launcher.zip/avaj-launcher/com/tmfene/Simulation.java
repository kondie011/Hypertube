package com.tmfene;

import java.io.*;
import java.util.ArrayList;

import static java.lang.System.exit;

public class Simulation {
    public static PrintWriter writer;
    public static int it;

    public static void main(String[] args) {

        AircraftFactory aircraftFactory = new AircraftFactory();
        WeatherTower weatherTower = new WeatherTower();
        ArrayList<Flyable> f = new ArrayList<Flyable>();

        try {
            if (args.length < 1) throw new IOException();
            String inputFile = args[0];
            File outputFile = new File("simulation.txt");
            writer = new PrintWriter(outputFile);
            if (outputFile.exists()) writer.print("");

            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile)));
            String nextLine;
            int line = 0;

            while ((nextLine = br.readLine()) != null) {
                if (line == 0) {
                    it = (Integer.parseInt(nextLine));
                    if (it < 0) throw new IOException();
                } else {
                    String[] currLine = nextLine.split(" ");
                    if (currLine.length == 5)
                        f.add(aircraftFactory.newAircraft(currLine[0], currLine[1], Integer.parseInt(currLine[2]), Integer.parseInt(currLine[3]), Integer.parseInt(currLine[4])));
                    else throw new IOException();
                }
                line++;
            }
            br.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            exit(1);
        }

        for (Flyable aircraft : f) {
            aircraft.registerTower(weatherTower);
        }

        while (it-- > 0) weatherTower.changeWeather();

        writer.close();
    }
}