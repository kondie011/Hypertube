package com.tmfene;


public class AircraftFactory {

    public Flyable newAircraft(String type, String name, int longtitude, int latitude, int height) {
        Coordinates coordinates = new Coordinates(longtitude, latitude, height);
        if (type.equals("Helicopter")) {
            return new Helicopter(name, coordinates);
        } else if (type.equals("JetPlane")) {
            return new JetPlane(name, coordinates);
        } else if (type.equals("Baloon")) {
            return new Baloon(name, coordinates);
        } else {
            return null;
        }
    }
}
