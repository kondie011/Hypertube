package com.tmfene;

public class JetPlane extends Aircraft implements Flyable {
    private WeatherTower weatherTower;

    JetPlane(String name, Coordinates coordinates){
        super(name, coordinates);
    }

    public void updateConditions(){
        String passweather = weatherTower.getWeather(this.coordinates);
        if (passweather.equals("SUN")){
            this.coordinates = new Coordinates(coordinates.getLongitude() + 0,
                    coordinates.getLatitude() + 10,
                    coordinates.getHeight() + 2 > 100 ? 100 : coordinates.getHeight() + 2);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): This Sun Is Nice ayoba.");
        }
        else if (passweather.equals("RAIN")){
            this.coordinates = new Coordinates(coordinates.getLongitude()+ 0,
                    coordinates.getLatitude() + 5,
                    coordinates.getHeight() + 0 > 100 ? 100 : coordinates.getHeight() + 0);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): OMG this Rain be killing my vibe.");
        }
        else if (passweather.equals("FOG")){
            this.coordinates = new Coordinates(coordinates.getLongitude()+ 0,
                    coordinates.getLatitude() + 1,
                    coordinates.getHeight() + 0 > 100 ? 100 : coordinates.getHeight() + 0);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): FOG FOG FOK I cant see.");
        }
        else if (passweather.equals("SNOW")){
            this.coordinates = new Coordinates(coordinates.getLongitude()+ 0,
                    coordinates.getLatitude() + 0,
                    coordinates.getHeight() - 7 < 0 ? 0 : coordinates.getHeight() - 7);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): Ishweza its cold.");
        } else {
            Simulation.writer.println("It's doom's day on Earth!!!");
        }
        //Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): got blah bhla bhlab seriously.");

        if (this.coordinates.getHeight() == 0) {
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): landing.");
            this.weatherTower.unregister(this);
            Simulation.writer.println("Tower says: " + this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + ")" + " unregistered from weather tower.");
        }

    }

    public void registerTower(WeatherTower weatherTower) {
        this.weatherTower = weatherTower;
        this.weatherTower.register(this);
        Simulation.writer.println("Tower says: " + this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + ") registered to weather tower.");
    }
}
