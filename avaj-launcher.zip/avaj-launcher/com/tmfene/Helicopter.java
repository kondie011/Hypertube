package com.tmfene;

public class Helicopter extends Aircraft implements Flyable {
    private WeatherTower weatherTower;

    Helicopter(String name, Coordinates coordinates){
        super(name, coordinates);

    }

    public void updateConditions(){
        String passweather = weatherTower.getWeather(this.coordinates);
        if (passweather.equals("SUN")){
            this.coordinates = new Coordinates(coordinates.getLongitude() + 10,
                    coordinates.getLatitude() + 0,
                    coordinates.getHeight() + 2 > 100 ? 100 : coordinates.getHeight() + 2);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): Enjoying the weather.");
        }
        else if (passweather.equals("RAIN")){
            this.coordinates = new Coordinates(coordinates.getLongitude() + 5,
                    coordinates.getLatitude()+ 0,
                    coordinates.getHeight() + 0 > 100 ? 100 : coordinates.getHeight() + 0);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): Rain be disturbing my blades.");
        }
        else if (passweather.equals("FOG")){
            this.coordinates = new Coordinates(coordinates.getLongitude()+ 1,
                    coordinates.getLatitude() + 0,
                    coordinates.getHeight() + 0 > 100 ? 100 : coordinates.getHeight() + 0);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): FOK!! Angiboni.");
        }
        else if (passweather.equals("SNOW")){
            this.coordinates = new Coordinates(coordinates.getLongitude() + 0,
                    coordinates.getLatitude() + 0,
                    coordinates.getHeight() - 12 < 0 ? 0 : coordinates.getHeight() - 12);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): Ishweza its cold.");
        }
        if (this.coordinates.getHeight() == 0) {
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): landing.");
            this.weatherTower.unregister(this);
            Simulation.writer.println("Tower says: " + this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + ")" + " unregistered from weather tower.");
        }

    }

    public void registerTower(WeatherTower weatherTower) {
        this.weatherTower = weatherTower;
        this.weatherTower.register(this);
        Simulation.writer.println("Tower says: " + this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + ") registered to weather tower.");

    }
}
