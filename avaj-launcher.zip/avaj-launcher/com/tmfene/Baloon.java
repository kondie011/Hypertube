package com.tmfene;

public class Baloon extends Aircraft implements Flyable {
    private WeatherTower weatherTower;

    Baloon(String name, Coordinates coordinates){
        super(name, coordinates);
    }

    public void updateConditions(){
        String passweather = weatherTower.getWeather(this.coordinates);
        if (passweather.equals("SUN")){
            this.coordinates = new Coordinates(coordinates.getLongitude() + 2,
                    coordinates.getLatitude()+ 0,
                    coordinates.getHeight() + 4 > 100 ? 100 : coordinates.getHeight() + 4);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): This Weather is good.");
        }
        else if (passweather.equals("RAIN")){
            this.coordinates = new Coordinates(coordinates.getLongitude()+ 0,
                    coordinates.getLatitude()+ 0,
                    coordinates.getHeight() - 5 < 0 ? 0 : coordinates.getHeight() - 5);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): Rain might kill my vibe.");
        }
        else if (passweather.equals("FOG")){
            this.coordinates = new Coordinates(coordinates.getLongitude()+ 0,
                    coordinates.getLatitude()+ 0,
                    coordinates.getHeight() - 3 < 0 ? 0 : coordinates.getHeight() - 3);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): Fog i cant see.");
        }
        else if (passweather.equals("SNOW")){
            this.coordinates = new Coordinates(coordinates.getLongitude()+ 0,
                    coordinates.getLatitude()+ 0,
                    coordinates.getHeight() - 15 < 0 ? 0 : coordinates.getHeight() - 15);
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): Snow is cold.");
        }
        if (this.coordinates.getHeight() == 0) {
            Simulation.writer.println(this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + "): landing.");
            this.weatherTower.unregister(this);
            Simulation.writer.println("Tower says: " + this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + ")" + " unregistered from weather tower.");
        }

    }

    public void registerTower(WeatherTower weatherTower) {
        this.weatherTower = weatherTower;
        this.weatherTower.register(this);
        Simulation.writer.println("Tower says: " + this.getClass().getSimpleName() + "#" + this.name + "(" + this.id + ") registered to weather tower.");

    }
}
